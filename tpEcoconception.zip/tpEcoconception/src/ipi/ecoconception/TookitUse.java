package ipi.ecoconception;

import java.io.Console;

public class TookitUse {

	public static void main(String[] args) {
	}

}
