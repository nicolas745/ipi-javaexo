package ipi.ecoconception;

public class Constants {
	public static final String DOMAIN_1 = "domain1.com";
	public static final String DOMAIN_2 = "domain2.com";
	public static final String DOMAIN_3 = "domain3.com";
	public static final String DOMAIN_4 = "domain4.com";
	public static final String DOMAIN_5 = "domain5.com";
	public static final String DOMAIN_6 = "domain6.com";
	private Constants() {
		
	}
}
