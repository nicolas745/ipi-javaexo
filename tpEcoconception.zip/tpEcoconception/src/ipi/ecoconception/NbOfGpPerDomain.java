package ipi.ecoconception;

public class NbOfGpPerDomain {
    private String domain;

    public NbOfGpPerDomain(String domain) {
        this.domain = domain; 
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }
}

