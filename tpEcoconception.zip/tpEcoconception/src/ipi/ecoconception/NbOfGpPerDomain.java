package ipi.ecoconception;

public class NbOfGpPerDomain {

}
