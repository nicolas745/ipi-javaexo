package ipi.ecoconception;

public class Tool {
	private String name;
	private String Description;
	public Tool() {}
	public String getname() {
		return name;
	}
	public String getDesc() {
		return Description;
	}
	public void setDesc(String desc) {
		this.Description = desc;
	}

	public void setname(String name) {
		this.name = name;
	}
}
