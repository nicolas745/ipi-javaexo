package ipi.ecoconception;

public class Tool {
	private String name;
	private String Description;
	public Tool() {}
	public String getname() {
		return name;
	}
	public String getDesc() {
		return getDesc();
	}
}
